public class Cat
{
}