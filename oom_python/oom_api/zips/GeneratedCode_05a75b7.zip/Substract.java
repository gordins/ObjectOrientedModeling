public class Substract extends Operation {
	public void compute(Number[] number) {
		throw new UnsupportedOperationException();
	}
}