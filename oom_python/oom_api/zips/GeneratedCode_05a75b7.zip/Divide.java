public class Divide extends Operation {
	public void compute(Number[] number) {
		throw new UnsupportedOperationException();
	}
}