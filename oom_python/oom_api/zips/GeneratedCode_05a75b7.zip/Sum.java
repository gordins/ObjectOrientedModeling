public class Sum extends Operation {
	public void compute(Number[] number) {
		throw new UnsupportedOperationException();
	}
}