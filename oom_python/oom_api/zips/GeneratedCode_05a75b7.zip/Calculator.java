public class Calculator {
	public Operation[] operation;
	private Number[] inputnumbers;
	private static Calculator instance;
	private Calculator() {
	}
	public void compute() {
		throw new UnsupportedOperationException();
	}
	public static Calculator getInstance() {
		throw new UnsupportedOperationException();
	}
	public void convertinput(InputString inputstring) {
		throw new UnsupportedOperationException();
	}
}