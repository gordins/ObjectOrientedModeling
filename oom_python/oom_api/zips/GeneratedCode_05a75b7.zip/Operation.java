public abstract class Operation {
	public abstract void compute(Number[] number);
}