public class Stefan extends Human {
}