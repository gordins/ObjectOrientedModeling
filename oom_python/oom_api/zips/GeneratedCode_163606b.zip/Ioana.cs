public class Ioana : Stumbea
{
}