public class Stumbea
{
	protected Gordin gordin;
}