public class Stefan : Gordin
{
}