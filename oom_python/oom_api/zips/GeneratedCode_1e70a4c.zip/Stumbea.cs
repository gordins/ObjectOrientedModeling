using System;
namespace GeneratedCode
{
	public class Stumbea
	{
	}
}
