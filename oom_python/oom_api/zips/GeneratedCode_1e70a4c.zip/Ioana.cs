using System;
namespace GeneratedCode
{
	public class Ioana : Stumbea
	{
	}
}
