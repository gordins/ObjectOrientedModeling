public class Mihai {
	public void swim(Eveline eveline) {
		throw new UnsupportedOperationException();
	}
	public void swim() {
		throw new UnsupportedOperationException();
	}
	public void swim(Dog dog) {
		throw new UnsupportedOperationException();
	}
	public void fuck(Dog dog) {
		throw new UnsupportedOperationException();
	}
}