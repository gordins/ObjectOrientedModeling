public class Human {
}