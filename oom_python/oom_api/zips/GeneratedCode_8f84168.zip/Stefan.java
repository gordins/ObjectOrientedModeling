protected final abstract class Stefan extends Human {
	protected final static String car;
	private static Stefan instance;
	private Stefan() {
	}
	public static Stefan getInstance() {
		throw new UnsupportedOperationException();
	}
	public void swim() {
		throw new UnsupportedOperationException();
	}
	protected void cook() {
		throw new UnsupportedOperationException();
	}
	private void write() {
		throw new UnsupportedOperationException();
	}
	public void dance(Dog[] dog) {
		throw new UnsupportedOperationException();
	}
	public void sing(Dog[] dog, Cat cat, Knife[] knife) {
		throw new UnsupportedOperationException();
	}
}