public class Cat {
}