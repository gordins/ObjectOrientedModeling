public class Ana {
	public Cow cow;
}