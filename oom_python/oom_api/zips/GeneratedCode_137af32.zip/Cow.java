public class Cow {
}