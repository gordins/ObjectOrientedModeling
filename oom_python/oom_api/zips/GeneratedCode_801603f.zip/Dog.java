public class Dog {
}