public class Ana {
	public void fly() {
		throw new UnsupportedOperationException();
	}
}