public class Dog
{
}