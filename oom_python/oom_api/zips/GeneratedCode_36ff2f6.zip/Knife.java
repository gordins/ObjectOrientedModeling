public class Knife {
}