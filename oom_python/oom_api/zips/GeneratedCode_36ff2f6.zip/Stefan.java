protected final abstract class Stefan extends Human {
	protected final static String car;
	private static Stefan instance;
	private Stefan() {
	}
	public static Stefan getInstance() {
		throw new NotImplementedException();
	}
	public void swim() {
		throw new NotImplementedException();
	}
	protected void cook() {
		throw new NotImplementedException();
	}
	private void write() {
		throw new NotImplementedException();
	}
	public void dance(Dog[] dog) {
		throw new NotImplementedException();
	}
	public void sing(Dog[] dog, Cat cat, Knife[] knife) {
		throw new NotImplementedException();
	}
}