public class Mihai
{
	public void swim(Eveline eveline)
	{
		throw new NotImplementedException();
	}
	public void swim()
	{
		throw new NotImplementedException();
	}
	public void swim(Dog dog)
	{
		throw new NotImplementedException();
	}
	public void fuck(Dog dog)
	{
		throw new NotImplementedException();
	}
}