public class Stumbea
{
	private static Stumbea instance;
	private Stumbea()
	{
	}
	public static Stumbea getInstance()
	{
		throw new NotImplementedException();
	}
}