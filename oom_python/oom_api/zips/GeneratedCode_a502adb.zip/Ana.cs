using System;
namespace GeneratedCode
{
	public class Ana
	{
		public void fly()
		{
			throw new NotImplementedException();
		}
	}
}
