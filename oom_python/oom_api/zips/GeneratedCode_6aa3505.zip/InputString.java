public class InputString {
	public String value;
}