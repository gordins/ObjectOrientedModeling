public class Number {
	public int value;
}