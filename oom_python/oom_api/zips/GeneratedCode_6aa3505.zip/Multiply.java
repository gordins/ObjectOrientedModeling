public class Multiply extends Operation {
	public void compute(Number[] number) {
		throw new UnsupportedOperationException();
	}
}