public class Ana extends Human {
}