public class Entity {
	public Variable[] variable;
	public Method[] method;
	public Constructor[] constructor;
	public String name;
	public String type;
	public String accessmodifier;
	public boolean issealed;
	public boolean isabstract;
	public String inherits;
}