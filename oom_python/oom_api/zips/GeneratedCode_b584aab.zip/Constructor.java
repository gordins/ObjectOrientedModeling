public class Constructor {
	public String accessmodifier;
}