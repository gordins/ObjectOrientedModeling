public class Giosanu
{
	private Eveline[] dog;
}