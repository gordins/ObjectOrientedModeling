public class Variable {
	public String name;
	public String type;
	public boolean iscollection;
	public String accessmodifier;
	public boolean isconst;
	public boolean isstatic;
}