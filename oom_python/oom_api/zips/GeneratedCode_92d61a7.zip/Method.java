public class Method {
	public String name;
	public String returnedtype;
	public String accessmodifier;
	public boolean issealed;
	public boolean isstatic;
	public boolean isabstract;
	public Parameter[] parameter;
}