public class Parameter {
	public String name;
	public String type;
	public boolean iscollection;
}