public class Constructor {
	public String accessmodifier;
	public Parameter[] parameter;
}