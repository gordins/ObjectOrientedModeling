public class Ana : Human
{
}